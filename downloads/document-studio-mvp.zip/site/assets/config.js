window.STUDIO_API_BASE = "";
window.STUDIO_LOCAL_EXPORT = true;
